// Utils/fechaComercial.js
import moment from "moment";

const getFechaComercial = () => {
    const ahora = moment();
    if (ahora.hour() < Number(process.env.REACT_APP_horaCierre)) {
        return ahora.subtract(1, 'day').format("DD-MM-YYYY");
    }
    return ahora.format("DD-MM-YYYY");
};

//TODO VER TEMA GET RANGO JORNADA

export default getFechaComercial;